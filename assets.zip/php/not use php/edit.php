<?php
    include_once 'dbconfig.php';

    if(isset($_POST["edit"]))
    {

    }
?>